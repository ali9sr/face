import datetime
import time
import cv2
import csv
import skimage.metrics
from skimage import *

pepole = ['people/ali1', 'people/ali2']

face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

cap = cv2.VideoCapture(0)

reference_img = ''

result = False

pic_ = ''

while True:
    ret, frame = cap.read()

    faces = face_cascade.detectMultiScale(frame, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    cv2.imshow('frame', frame)
    k = cv2.waitKey(1) & 0xff
    if k == 27:
        break

    if result:
        break

    for (x, y, w, h) in faces:
        face_img = frame[y:y + h, x:x + w]

        face_img = cv2.cvtColor(face_img, cv2.COLOR_BGR2GRAY)

        for pic in range(len(pepole)):
            reference_img = cv2.imread(pepole[pic] + '.jpg')
            pic_ = pepole[pic] + '.jpg'

        reference_img = cv2.cvtColor(reference_img, cv2.COLOR_BGR2GRAY)

        reference_img = cv2.resize(reference_img, face_img.shape)

        score = skimage.metrics.structural_similarity(face_img, reference_img, full=True)

        print(score[0])

        if score[0] > 0.3:
            print('true')

            with open('result.csv', 'a') as f:
                writer = csv.writer(f)
                writer.writerow([datetime.datetime.now(), pic_])
            result = True

        else:
            print('false')
            break

cap.release()
